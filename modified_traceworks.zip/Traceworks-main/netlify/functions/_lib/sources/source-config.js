const TEXAS_FIRST_SOURCE_CONFIG = {
  countyProperty: [
    {
      id: 'tx_harris_appraisal',
      name: 'Harris County Appraisal District',
      type: 'html',
      request: { urlTemplate: 'https://hcad.org/property-search/property-search-results/?q={owner}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { account: 1, owner: 2, address: 3 }
      }
    },
    {
      id: 'tx_travis_appraisal',
      name: 'Travis Central Appraisal District',
      type: 'html',
      request: { urlTemplate: 'https://www.traviscad.org/propertysearch?owner={owner}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { account: 1, owner: 2, address: 3 }
      }
    },
    {
      id: 'tx_dallas_appraisal',
      name: 'Dallas Central Appraisal District',
      type: 'html',
      request: { urlTemplate: 'https://www.dallascad.org/SearchOwner.aspx?owner={owner}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { account: 1, owner: 2, address: 3 }
      }
    },
    {
      id: 'tx_bexar_appraisal',
      name: 'Bexar Appraisal District',
      type: 'html',
      request: { urlTemplate: 'https://www.bcad.org/clientdb/?cid=1&owner={owner}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { account: 1, owner: 2, address: 3 }
      }
    },
    {
      id: 'tx_tarrant_appraisal',
      name: 'Tarrant Appraisal District',
      type: 'html',
      request: { urlTemplate: 'https://www.tad.org/property/search?owner={owner}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { account: 1, owner: 2, address: 3 }
      }
    }
  ],
  countyRecorder: [
    {
      id: 'tx_harris_clerk_real_property',
      name: 'Harris County Clerk Real Property Search',
      type: 'html',
      request: { urlTemplate: 'https://www.cclerk.hctx.net/applications/websearch/RP.aspx?name={owner}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { recordingDate: 1, instrumentType: 2, grantorGrantee: 3, instrumentNumber: 4 }
      }
    },
    {
      id: 'tx_dallas_county_clerk',
      name: 'Dallas County Clerk Recorder Search',
      type: 'html',
      request: { urlTemplate: 'https://www.dallascounty.org/government/county-clerk/recording/search.php?name={owner}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { recordingDate: 1, instrumentType: 2, grantorGrantee: 3, instrumentNumber: 4 }
      }
    }
  ],
  probateIndex: [
    {
      id: 'tx_travis_probate_index',
      name: 'Travis County Probate Search',
      type: 'html',
      request: { urlTemplate: 'https://odysseyweb.traviscountytx.gov/Portal/Home/WorkspaceMode?p={decedent}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { caseNumber: 1, filingDate: 2, status: 3 }
      }
    },
    {
      id: 'tx_tarrant_probate_index',
      name: 'Tarrant County Probate Search',
      type: 'html',
      request: { urlTemplate: 'https://courts.tarrantcounty.com/Case/Search?name={decedent}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { caseNumber: 1, filingDate: 2, status: 3 }
      }
    }
  ],
  entitySearch: [
    {
      id: 'tx_sos_entity_search',
      name: 'Texas Secretary of State Entity Search',
      type: 'html',
      request: { urlTemplate: 'https://mycpa.cpa.state.tx.us/coa/search.do?entityName={entityName}', method: 'GET' },
      extraction: {
        itemRegex: '<tr[^>]*>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>\\s*<td[^>]*>([^<]*)</td>',
        map: { entityName: 1, state: 2, status: 3, filingNumber: 4 }
      }
    },
    {
      id: 'opencorporates_company_search',
      name: 'OpenCorporates Company Search',
      type: 'json',
      request: { urlTemplate: 'https://api.opencorporates.com/v0.4/companies/search?q={entityName}&per_page=5', method: 'GET' },
      extraction: {
        itemsPath: 'results.companies',
        map: { entityName: 'company.name', state: 'company.jurisdiction_code', status: 'company.current_status', filingNumber: 'company.company_number' }
      }
    },
    {
      id: 'sec_edgar_company_search',
      name: 'SEC EDGAR Company Search',
      type: 'html',
      request: { urlTemplate: 'https://www.sec.gov/edgar/search/#/q={entityName}', method: 'GET', headers: { 'user-agent': 'TraceWorks public records research' } },
      extraction: {
        itemRegex: '<h4[^>]*>([^<]*)</h4>',
        map: { entityName: 1 }
      }
    }
  ]
};

export function loadSourceConfig(env = process.env) {
  const raw = String(env.PUBLIC_RECORD_SOURCE_CONFIG || '').trim();
  if (!raw) return TEXAS_FIRST_SOURCE_CONFIG;
  try {
    const parsed = JSON.parse(raw);
    return {
      countyProperty: Array.isArray(parsed.countyProperty) ? parsed.countyProperty : TEXAS_FIRST_SOURCE_CONFIG.countyProperty,
      countyRecorder: Array.isArray(parsed.countyRecorder) ? parsed.countyRecorder : TEXAS_FIRST_SOURCE_CONFIG.countyRecorder,
      probateIndex: Array.isArray(parsed.probateIndex) ? parsed.probateIndex : TEXAS_FIRST_SOURCE_CONFIG.probateIndex,
      entitySearch: Array.isArray(parsed.entitySearch) ? parsed.entitySearch : TEXAS_FIRST_SOURCE_CONFIG.entitySearch
    };
  } catch {
    throw new Error('PUBLIC_RECORD_SOURCE_CONFIG must be valid JSON.');
  }
}
