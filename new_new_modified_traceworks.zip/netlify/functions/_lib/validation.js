const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function clean(value) {
  return String(value ?? '').trim();
}

function normalizeWebsite(value) {
  const v = clean(value);
  if (!v) return '';
  if (/^https?:\/\//i.test(v)) return v;
  return `https://${v}`;
}

export function normalizeCheckoutPayload(raw) {
  return {
    packageId: clean(raw.packageId),
    customerName: clean(raw.customerName),
    customerEmail: clean(raw.customerEmail).toLowerCase(),
    companyName: clean(raw.companyName),
    website: normalizeWebsite(raw.website),
    goals: clean(raw.goals),
    searchName: clean(raw.searchName),
    searchPhone: clean(raw.searchPhone),
    searchAddress: clean(raw.searchAddress),
    legalConsent: raw.legalConsent === true || raw.legalConsent === 'on' || raw.legalConsent === 'true',
    tosConsent: raw.tosConsent === true || raw.tosConsent === 'on' || raw.tosConsent === 'true'
  };
}

export function validateCheckoutPayload(payload) {
  const errors = [];
  if (!payload.packageId) errors.push('Package selection is required.');
  if (!payload.customerName || payload.customerName.length < 2) errors.push('Requestor name is required.');
  if (!payload.customerEmail || !EMAIL_RE.test(payload.customerEmail)) errors.push('A valid requestor email is required.');
  // At least one identifying field (subject/entity, searchName, searchPhone, searchAddress, or website) must be provided.
  const hasIdentifier =
    (payload.companyName && payload.companyName.length >= 2) ||
    (payload.searchName && payload.searchName.length >= 1) ||
    (payload.searchPhone && payload.searchPhone.length >= 3) ||
    (payload.searchAddress && payload.searchAddress.length >= 3) ||
    Boolean(payload.website);
  if (!hasIdentifier) {
    errors.push('Provide at least one subject identifier (name, phone, address, or website).');
  }
  if (payload.goals && payload.goals.length > 1200) errors.push('Case objective is too long.');
  if (payload.website) {
    try { new URL(payload.website); } catch { errors.push('Website/profile URL is invalid.'); }
  }
  if (!payload.legalConsent) errors.push('Legal use acknowledgement is required.');
  if (!payload.tosConsent) errors.push('Terms consent is required.');
  return errors;
}
