import {
  appraisalDistrictScraper,
  taxCollectorScraper,
  parcelGisLookup,
  countyClerkDeedIndexScraper,
  grantorGranteeIndexScraper,
  mortgageTrustDeedScraper,
  chainContinuityAnalyzer,
  obituaryIndexScraper,
  probateCaseIndexScraper,
  publicPeopleAssociationLookup,
  heirCandidateScorer,
  crossSourceDiscrepancyAnalyzer,
  confidenceMatrixBuilder,
  recommendedNextStepsGenerator,
  // generic OSINT tools – these provide additional investigative data and
  // are selectively used by each report type below. See source-modules.js
  // for descriptions and environment variable names. When adding a new
  // scraper here, also update the corresponding requireConfiguredSources
  // call in the relevant report function.
  // property & asset oriented tools
  buildingPermitSearch,
  propertyTitleChainSearch,
  taxLienSearch,
  judgmentLienSearch,
  assetSearch,
  riskFlagsSearch,
  hoaSearch,
  landUsePlanningSearch,
  // corporate & legal tools
  corporateFilingsSearch,
  uccFilingSearch,
  bankruptcySearch,
  licenseViolationSearch,
  // personal heir location tools
  heirBeneficiarySearch,
  identityVerificationSearch,
  phoneNumberLookupSearch,
  aliasSearch,
  socialMediaSearch,
  marriageDivorceRecordSearch,
  voterRegistrationSearch,
  identitySnapshotSearch,
  // comprehensive‑only tools
  dmvRecordsSearch,
  professionalLicenseSearch,
  courtCaseSearch,
  environmentalHazardSearch,
  educationVerificationSearch,
  vehicleRegistrationSearch,
  militaryServiceSearch,
  domainOwnershipSearch,
  employmentVerificationSearch,
  businessSearch,
  bankAccountSearch,
  serviceNotesSearch,
  publicRecordsCrossRefSearch,
  bondSearch,
  immigrationStatusSearch,
  medicalLicenseSearch,
  wildlifeLicenseSearch
} from './source-modules.js';
import { REPORT_TIER } from './tier-mapping.js';
import { SOURCE_STATUS } from './workflow-results.js';
import { gatherPublicRecordIntel } from './public-records.js';

function requireConfiguredSources(keys, env = process.env) {
  const strict = String(env.PAID_FULFILLMENT_STRICT || 'true').toLowerCase() !== 'false';
  if (!strict) return;
  const missing = keys.filter((k) => !String(env[k] || '').trim());
  if (missing.length) throw new Error(`Missing required source configuration: ${missing.join(', ')}`);
}

function overallFromSources(sources) {
  if (sources.some((s) => s.status === SOURCE_STATUS.ERROR)) return 'failed';
  if (sources.some((s) => [SOURCE_STATUS.PARTIAL, SOURCE_STATUS.UNAVAILABLE, SOURCE_STATUS.BLOCKED].includes(s.status))) return 'partial';
  return 'complete';
}

function missingReasons(sources) {
  return sources
    .filter((s) => [SOURCE_STATUS.UNAVAILABLE, SOURCE_STATUS.BLOCKED, SOURCE_STATUS.ERROR].includes(s.status))
    .map((s) => `${s.sourceId}: ${s.errorDetail || s.status}`);
}

function mkWorkflow(order, tier, sources, extra = {}) {
  const startedAt = extra.startedAt || new Date().toISOString();
  const completedAt = new Date().toISOString();
  const overallStatus = overallFromSources(sources);
  const reasons = missingReasons(sources);
  return {
    orderId: order.order_id || order.caseRef,
    tier,
    startedAt,
    completedAt,
    inputs: order.input_criteria || { subjectName: order.subjectName, website: order.website, goals: order.goals },
    sources,
    overallStatus,
    partialReasons: overallStatus === 'partial' ? reasons : [],
    failureReasons: overallStatus === 'failed' ? reasons : [],
    ...extra
  };
}

export async function runStandardReport(order, ctx = {}) {
  // The standard report requires configuration for the core property APIs and a
  // suite of additional OSINT sources. If any of these environment variables
  // are missing the workflow will abort to avoid silently skipping data.
  requireConfiguredSources([
    'APPRAISAL_API_URL',
    'TAX_COLLECTOR_API_URL',
    'PARCEL_GIS_API_URL',
    // additional OSINT endpoints for property and asset analysis
    'BUILDING_PERMIT_API_URL',
    'PROPERTY_CHAIN_API_URL',
    'TAX_LIEN_API_URL',
    'JUDGMENT_LIEN_API_URL',
    'ASSET_API_URL',
    'RISK_FLAGS_API_URL',
    'HOA_API_URL',
    'LAND_USE_API_URL'
  ]);
  const county = order.county || process.env.DEFAULT_COUNTY || '';
  const state = order.state || process.env.DEFAULT_STATE || '';
  const query = order.searchName || order.searchPhone || order.searchAddress || order.subjectName || order.website || order.goals || '';

  const publicRecords = await gatherPublicRecordIntel({ packageKey: 'standard', input: { address: order.searchAddress || order.website || '', ownerName: order.searchName || order.subjectName || '', county, state } }, { fetchImpl: ctx.fetchImpl });

  const s1 = await appraisalDistrictScraper({ county, state, query, fetchImpl: ctx.fetchImpl });
  const parcelId = s1?.data?.parcelId || s1?.data?.apn || '';
  const s2 = await taxCollectorScraper({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s3 = await parcelGisLookup({ county, state, query, fetchImpl: ctx.fetchImpl });

  // Invoke additional OSINT scrapers for the standard package. These calls
  // leverage parcel identifiers when available and otherwise rely on
  // county/state context to pull relevant records. Each returns a
  // standardized source result which will be included in the final workflow.
  const s4 = await buildingPermitSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s5 = await propertyTitleChainSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s6 = await taxLienSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s7 = await judgmentLienSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s8 = await assetSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s9 = await riskFlagsSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s10 = await hoaSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s11 = await landUsePlanningSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });

  return mkWorkflow(order, 'standard', [
    ...publicRecords.sources,
    s1,
    s2,
    s3,
    s4,
    s5,
    s6,
    s7,
    s8,
    s9,
    s10,
    s11
  ], { startedAt: ctx.startedAt, publicRecords });
}

export async function runTitlePropertyReport(order, ctx = {}) {
  // The title/property report relies on core property APIs plus a range of
  // corporate and lien data sources. Missing configuration for any of these
  // endpoints will cause the workflow to abort early.
  requireConfiguredSources([
    'APPRAISAL_API_URL',
    'COUNTY_CLERK_API_URL',
    'GRANTOR_GRANTEE_API_URL',
    // additional OSINT endpoints
    'CORPORATE_FILINGS_API_URL',
    'UCC_FILINGS_API_URL',
    'BANKRUPTCY_API_URL',
    'PROPERTY_CHAIN_API_URL',
    'TAX_LIEN_API_URL',
    'JUDGMENT_LIEN_API_URL',
    'BUILDING_PERMIT_API_URL',
    'VIOLATION_API_URL'
  ]);
  const county = order.county || process.env.DEFAULT_COUNTY || '';
  const state = order.state || process.env.DEFAULT_STATE || '';
  const query = order.searchName || order.searchPhone || order.searchAddress || order.subjectName || order.website || order.goals || '';

  const publicRecords = await gatherPublicRecordIntel({ packageKey: 'title_property', input: { address: order.searchAddress || order.website || '', ownerName: order.searchName || order.subjectName || '', county, state, parcel: order.parcelId || '' } }, { fetchImpl: ctx.fetchImpl });

  const s1 = await appraisalDistrictScraper({ county, state, query, fetchImpl: ctx.fetchImpl });
  const parcelId = s1?.data?.parcelId || s1?.data?.apn || '';
  const s2 = await countyClerkDeedIndexScraper({ county, state, query, queryType: 'parcel', fetchImpl: ctx.fetchImpl });
  const s3 = await grantorGranteeIndexScraper({ county, state, ownerName: order.subjectName, parcelId, fetchImpl: ctx.fetchImpl });
  const s4 = await mortgageTrustDeedScraper({ county, state, parcelId, fetchImpl: ctx.fetchImpl });

  // Supplement core deed and mortgage results with corporate and lien searches.
  const s5 = await corporateFilingsSearch({ state, ownerName: order.subjectName || '', query, fetchImpl: ctx.fetchImpl });
  const s6 = await uccFilingSearch({ state, ownerName: order.subjectName || '', query, fetchImpl: ctx.fetchImpl });
  const s7 = await bankruptcySearch({ state, ownerName: order.subjectName || '', query, fetchImpl: ctx.fetchImpl });
  const s8 = await propertyTitleChainSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s9 = await taxLienSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s10 = await judgmentLienSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s11 = await buildingPermitSearch({ county, state, parcelId, fetchImpl: ctx.fetchImpl });
  const s12 = await licenseViolationSearch({ state, ownerName: order.subjectName || '', query, fetchImpl: ctx.fetchImpl });

  const instruments = [];
  if (Array.isArray(s2.data?.instruments)) instruments.push(...s2.data.instruments);
  if (Array.isArray(s3.data?.instruments)) instruments.push(...s3.data.instruments);
  const chain = chainContinuityAnalyzer(instruments);

  return mkWorkflow(order, 'title_property', [
    ...publicRecords.sources,
    s1,
    s2,
    s3,
    s4,
    s5,
    s6,
    s7,
    s8,
    s9,
    s10,
    s11,
    s12
  ], { startedAt: ctx.startedAt, chainAnalysis: chain, publicRecords });
}

export async function runHeirLocationReport(order, ctx = {}) {
  // Heir location reports require obituary and probate records plus a suite
  // of personal lookup tools. Missing any of these keys will abort the
  // workflow to ensure we never skip a source silently.
  requireConfiguredSources([
    'OBITUARY_API_URL',
    'PROBATE_API_URL',
    // additional OSINT endpoints for heir discovery
    'HEIR_API_URL',
    'IDENTITY_API_URL',
    'PHONE_API_URL',
    'ALIAS_API_URL',
    'SOCIAL_MEDIA_API_URL',
    'MARRIAGE_DIVORCE_API_URL',
    'VOTER_API_URL',
    'IDENTITY_SNAPSHOT_API_URL'
  ]);
  const county = order.county || process.env.DEFAULT_COUNTY || '';
  const state = order.state || process.env.DEFAULT_STATE || '';
  const decedentName = order.searchName || order.subjectName || '';

  const publicRecords = await gatherPublicRecordIntel({ packageKey: 'heir_location', input: { decedentName, ownerName: order.searchName || order.subjectName || '', county, state } }, { fetchImpl: ctx.fetchImpl });

  const s1 = await obituaryIndexScraper({ decedentName, county, state, deathYear: order.deathYear, fetchImpl: ctx.fetchImpl });
  const s2 = await probateCaseIndexScraper({ county, state, decedentName, deathYear: order.deathYear, fetchImpl: ctx.fetchImpl });
  const s3 = await publicPeopleAssociationLookup({ name: decedentName, lastKnownAddress: order.searchAddress || order.website || '', fetchImpl: ctx.fetchImpl });

  const candidates = Array.isArray(s3?.data?.candidates) ? s3.data.candidates : [];
  const scoredCandidates = heirCandidateScorer(candidates);

  // Additional searches to build a full picture of the decedent's network and
  // verify identities. These scrapers rely primarily on the decedent name.
  const s4 = await heirBeneficiarySearch({ name: decedentName, county, state, fetchImpl: ctx.fetchImpl });
  const s5 = await identityVerificationSearch({ name: decedentName, fetchImpl: ctx.fetchImpl });
  const s6 = await phoneNumberLookupSearch({ name: decedentName, fetchImpl: ctx.fetchImpl });
  const s7 = await aliasSearch({ name: decedentName, fetchImpl: ctx.fetchImpl });
  const s8 = await socialMediaSearch({ name: decedentName, fetchImpl: ctx.fetchImpl });
  const s9 = await marriageDivorceRecordSearch({ name: decedentName, fetchImpl: ctx.fetchImpl });
  const s10 = await voterRegistrationSearch({ name: decedentName, fetchImpl: ctx.fetchImpl });
  const s11 = await identitySnapshotSearch({ name: decedentName, fetchImpl: ctx.fetchImpl });

  return mkWorkflow(order, 'heir_location', [
    ...publicRecords.sources,
    s1,
    s2,
    s3,
    s4,
    s5,
    s6,
    s7,
    s8,
    s9,
    s10,
    s11
  ], { startedAt: ctx.startedAt, scoredCandidates, publicRecords });
}

export async function runComprehensiveReport(order, ctx = {}) {
  // Comprehensive reports not only merge the outputs of the individual
  // Standard, Title/Property, and Heir Location workflows, but also run a
  // number of additional OSINT scrapers that are only relevant at the most
  // exhaustive tier. All required environment variables must be set before
  // running; otherwise the workflow will abort instead of silently skipping
  // sources.
  requireConfiguredSources([
    // comprehensive‑only OSINT endpoints
    'DMV_RECORDS_API_URL',
    'PRO_LICENSE_API_URL',
    'COURT_CASE_API_URL',
    'HAZARD_API_URL',
    'EDUCATION_API_URL',
    'VEHICLE_API_URL',
    'MILITARY_API_URL',
    'DOMAIN_API_URL',
    'EMPLOYMENT_API_URL',
    'BUSINESS_API_URL',
    'BANK_API_URL',
    'SERVICE_NOTES_API_URL',
    'PUBLIC_RECORDS_API_URL',
    'BOND_API_URL',
    'IMMIGRATION_API_URL',
    'MEDICAL_LICENSE_API_URL',
    'WILDLIFE_LICENSE_API_URL'
  ]);

  // Run the sub‑reports in parallel.
  const [standard, title, heir] = await Promise.all([
    runStandardReport(order, ctx),
    runTitlePropertyReport(order, ctx),
    runHeirLocationReport(order, ctx)
  ]);

  // Determine search context for the extra scrapers.
  const county = order.county || process.env.DEFAULT_COUNTY || '';
  const state = order.state || process.env.DEFAULT_STATE || '';
  // Prefer explicit search fields provided by the user (searchName, searchPhone, searchAddress)
  // when constructing identifiers for comprehensive-only scrapers. Fall back to subjectName,
  // website, or goals if none of the explicit fields are present. This ensures that the
  // comprehensive tier leverages the same input semantics as the other tiers.
  const name = order.searchName || order.subjectName || '';
  const query =
    order.searchName ||
    order.searchPhone ||
    order.searchAddress ||
    order.subjectName ||
    order.website ||
    order.goals ||
    '';

  // Invoke comprehensive‑only scrapers. Each call returns a standardized
  // source result. Use whichever parameters are appropriate for the given
  // category; generics are acceptable because the downstream API knows
  // how to interpret them.
  const e1 = await dmvRecordsSearch({ name, county, state, query, fetchImpl: ctx.fetchImpl });
  const e2 = await professionalLicenseSearch({ name, county, state, query, fetchImpl: ctx.fetchImpl });
  const e3 = await courtCaseSearch({ name, county, state, query, fetchImpl: ctx.fetchImpl });
  const e4 = await environmentalHazardSearch({ county, state, query, fetchImpl: ctx.fetchImpl });
  const e5 = await educationVerificationSearch({ name, fetchImpl: ctx.fetchImpl });
  const e6 = await vehicleRegistrationSearch({ name, county, state, fetchImpl: ctx.fetchImpl });
  const e7 = await militaryServiceSearch({ name, fetchImpl: ctx.fetchImpl });
  const e8 = await domainOwnershipSearch({ domain: order.website || '', fetchImpl: ctx.fetchImpl });
  const e9 = await employmentVerificationSearch({ name, fetchImpl: ctx.fetchImpl });
  const e10 = await businessSearch({ name, fetchImpl: ctx.fetchImpl });
  const e11 = await bankAccountSearch({ name, fetchImpl: ctx.fetchImpl });
  const e12 = await serviceNotesSearch({ name, fetchImpl: ctx.fetchImpl });
  const e13 = await publicRecordsCrossRefSearch({ county, state, query, fetchImpl: ctx.fetchImpl });
  const e14 = await bondSearch({ name, fetchImpl: ctx.fetchImpl });
  const e15 = await immigrationStatusSearch({ name, fetchImpl: ctx.fetchImpl });
  const e16 = await medicalLicenseSearch({ name, fetchImpl: ctx.fetchImpl });
  const e17 = await wildlifeLicenseSearch({ name, fetchImpl: ctx.fetchImpl });

  // Consolidate all sources from the sub‑reports plus the additional scrapers.
  const allSources = [
    ...standard.sources,
    ...title.sources,
    ...heir.sources,
    e1,
    e2,
    e3,
    e4,
    e5,
    e6,
    e7,
    e8,
    e9,
    e10,
    e11,
    e12,
    e13,
    e14,
    e15,
    e16,
    e17
  ];

  // Build a combined workflow object with the enriched source list and the
  // public records from each tier for later inclusion in the report.
  const combined = mkWorkflow(order, 'comprehensive', allSources, {
    startedAt: ctx.startedAt,
    publicRecords: {
      standard: standard.publicRecords,
      title: title.publicRecords,
      heir: heir.publicRecords
    }
  });

  // Perform post‑processing analyses on the combined results.
  const discrepancy = crossSourceDiscrepancyAnalyzer(combined);
  const confidenceMatrix = confidenceMatrixBuilder(combined);
  const nextSteps = recommendedNextStepsGenerator(discrepancy, confidenceMatrix);

  return {
    ...combined,
    discrepancy,
    confidenceMatrix,
    nextSteps
  };
}

export function tierRunnerFor(purchasedTier) {
  if (purchasedTier === REPORT_TIER.STANDARD_REPORT) return runStandardReport;
  if (purchasedTier === REPORT_TIER.TITLE_PROPERTY_REPORT) return runTitlePropertyReport;
  if (purchasedTier === REPORT_TIER.HEIR_LOCATION_REPORT) return runHeirLocationReport;
  if (purchasedTier === REPORT_TIER.COMPREHENSIVE_REPORT) return runComprehensiveReport;
  throw new Error(`No workflow handler configured for purchased tier: ${purchasedTier}`);
}
