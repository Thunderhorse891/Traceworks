import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

// -----------------------------------------------------------------------------
// NOTE ON PERSISTENT STORAGE
//
// The original Traceworks store implementation used a simple JSON file on disk
// to persist all order data, webhook events, analytics, audit logs and queue
// jobs. While this approach works during local development, it does not
// scale beyond a single serverless instance. In production the data needs to
// live in a durable, centralised store so that multiple workers can read and
// update the same state concurrently.
//
// To support more robust deployments we now detect whether the environment
// exposes Supabase connection details via `SUPABASE_URL` and `SUPABASE_KEY`.
// When present, the store functions will transparently read/write data to
// Supabase tables via its PostgREST API. If those variables are not set the
// original file‑based store behaviour remains unchanged. This allows unit
// tests and local usage to continue functioning without a database while
// enabling a seamless migration path to full production.
//
// Before deploying to production you must create the necessary tables in
// Supabase with the following minimal schemas (column names can be altered
// but must match the property names used below):
//
//   create table orders (
//     caseRef text primary key,
//     status text,
//     createdAt timestamptz,
//     updatedAt timestamptz,
//     completedAt timestamptz,
//     lastAttemptAt timestamptz,
//     fulfillmentAttempts integer,
//     lastError text,
//     retryAt timestamptz,
//     customerEmail text
//   );
//
//   create table jobs (
//     id text primary key,
//     type text,
//     status text,
//     attempts integer,
//     payload jsonb,
//     createdAt timestamptz,
//     updatedAt timestamptz,
//     startedAt timestamptz,
//     completedAt timestamptz,
//     nextAttemptAt timestamptz,
//     lastError text
//   );
//
//   create table processed_webhook_events (
//     eventId text primary key,
//     createdAt timestamptz default now()
//   );
//
//   create table analytics (
//     id uuid default uuid_generate_v4() primary key,
//     event jsonb,
//     at timestamptz
//   );
//
//   create table dead_letters (
//     id uuid default uuid_generate_v4() primary key,
//     caseRef text,
//     jobId text,
//     error text,
//     source text,
//     at timestamptz
//   );
//
//   create table audit_logs (
//     id uuid default uuid_generate_v4() primary key,
//     event jsonb,
//     at timestamptz
//   );
//
// Make sure to enable Row Level Security (RLS) and configure policies so that
// inserts and updates from the service role key (provided via SUPABASE_KEY)
// succeed. See Supabase docs for details.

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_KEY;

// simple flag to determine whether to use Supabase for persistence
const useSupabase = Boolean(SUPABASE_URL && SUPABASE_KEY);

// Helper to perform requests against Supabase's PostgREST API. This function
// abstracts away header construction and JSON parsing. Any non‑2xx response
// will result in a rejected promise with a detailed error message. When
// performing mutations, setting the `Prefer` header to either
// `resolution=merge-duplicates` or `return=representation` is recommended.
async function supabaseRequest({ path, method = 'GET', body = null, headers = {} }) {
  const url = `${SUPABASE_URL.replace(/\/$/, '')}/rest/v1${path}`;
  const defaultHeaders = {
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json'
  };
  const opts = { method, headers: { ...defaultHeaders, ...headers } };
  if (body !== null && body !== undefined) {
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(url, opts);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Supabase request failed: ${res.status} ${res.statusText} – ${text}`);
  }
  // Supabase returns empty string for 204 responses; guard against JSON.parse errors.
  const raw = await res.text();
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

const STORE_PATH = process.env.TRACEWORKS_STORE_PATH || '.data/traceworks-store.json';
const EMPTY = { orders: {}, processedWebhookEvents: [], analytics: [], deadLetters: [], jobs: [], auditLogs: [] };

async function loadStore() {
  try {
    const raw = await readFile(STORE_PATH, 'utf8');
    return { ...EMPTY, ...JSON.parse(raw) };
  } catch {
    return { ...EMPTY };
  }
}

async function saveStore(store) {
  await mkdir(dirname(STORE_PATH), { recursive: true });
  const tmp = `${STORE_PATH}.tmp`;
  await writeFile(tmp, JSON.stringify(store, null, 2));
  await rename(tmp, STORE_PATH);
}

function makeJobId() {
  return `job_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function backoffMs(attempts) {
  return Math.min(60_000, 2 ** Math.max(0, attempts - 1) * 1000);
}

export async function upsertOrder(caseRef, patch) {
  // When configured to use Supabase, perform an upsert via the PostgREST API.
  if (useSupabase) {
    const now = new Date().toISOString();
    const obj = { caseRef, ...patch, updatedAt: now };
    // ensure createdAt exists on insert
    if (!('createdAt' in patch)) obj.createdAt = now;
    const body = [obj];
    const data = await supabaseRequest({
      path: '/orders?on_conflict=caseRef&return=representation',
      method: 'POST',
      body,
      headers: { Prefer: 'resolution=merge-duplicates,return=representation' }
    });
    // the response is an array of one element when return=representation
    return Array.isArray(data) ? data[0] : data;
  }
  // fallback to file store
  const store = await loadStore();
  const current = store.orders[caseRef] || { caseRef, createdAt: new Date().toISOString(), fulfillmentAttempts: 0 };
  store.orders[caseRef] = { ...current, ...patch, updatedAt: new Date().toISOString() };
  await saveStore(store);
  return store.orders[caseRef];
}

export async function incrementFulfillmentAttempt(caseRef) {
  const order = (await getOrder(caseRef)) || { caseRef, createdAt: new Date().toISOString(), fulfillmentAttempts: 0 };
  const next = Number(order.fulfillmentAttempts || 0) + 1;
  await upsertOrder(caseRef, { fulfillmentAttempts: next });
  return next;
}

export async function getOrder(caseRef) {
  if (useSupabase) {
    const data = await supabaseRequest({
      path: `/orders?caseRef=eq.${encodeURIComponent(caseRef)}&select=*`,
      method: 'GET'
    });
    return Array.isArray(data) && data.length > 0 ? data[0] : null;
  }
  const store = await loadStore();
  return store.orders[caseRef] || null;
}

export async function listOrders(limit = 200) {
  const max = Math.max(1, Math.min(1000, Number(limit) || 200));
  if (useSupabase) {
    const data = await supabaseRequest({
      path: `/orders?select=*&order=updatedAt.desc.nullslast&limit=${max}`,
      method: 'GET'
    });
    return Array.isArray(data) ? data : [];
  }
  const store = await loadStore();
  return Object.values(store.orders)
    .sort((a, b) => Date.parse(b.updatedAt || b.createdAt || 0) - Date.parse(a.updatedAt || a.createdAt || 0))
    .slice(0, max);
}

export async function isProcessedWebhookEvent(eventId) {
  if (useSupabase) {
    const data = await supabaseRequest({
      path: `/processed_webhook_events?eventId=eq.${encodeURIComponent(eventId)}&select=eventId`,
      method: 'GET'
    });
    return Array.isArray(data) && data.length > 0;
  }
  const store = await loadStore();
  return store.processedWebhookEvents.includes(eventId);
}

export async function markProcessedWebhookEvent(eventId) {
  if (useSupabase) {
    // Insert the event id, ignoring duplicates. Supabase respects the primary key
    // constraint on eventId if the table is defined accordingly.
    await supabaseRequest({
      path: '/processed_webhook_events',
      method: 'POST',
      body: [{ eventId }],
      headers: { Prefer: 'resolution=ignore-duplicates' }
    });
    return;
  }
  const store = await loadStore();
  if (!store.processedWebhookEvents.includes(eventId)) {
    store.processedWebhookEvents.push(eventId);
    if (store.processedWebhookEvents.length > 5000) {
      store.processedWebhookEvents = store.processedWebhookEvents.slice(-5000);
    }
    await saveStore(store);
  }
}

export async function recordAnalytics(event) {
  const entry = { ...event, at: new Date().toISOString() };
  if (useSupabase) {
    await supabaseRequest({ path: '/analytics', method: 'POST', body: [entry] });
    return;
  }
  const store = await loadStore();
  store.analytics.push(entry);
  if (store.analytics.length > 10000) store.analytics = store.analytics.slice(-10000);
  await saveStore(store);
}

export async function recordDeadLetter(entry) {
  const enhanced = { ...entry, at: new Date().toISOString() };
  if (useSupabase) {
    await supabaseRequest({ path: '/dead_letters', method: 'POST', body: [enhanced] });
    return;
  }
  const store = await loadStore();
  store.deadLetters.push(enhanced);
  if (store.deadLetters.length > 1000) store.deadLetters = store.deadLetters.slice(-1000);
  await saveStore(store);
}

export async function recordAuditEvent(entry) {
  const wrapped = { event: entry, at: new Date().toISOString() };
  if (useSupabase) {
    await supabaseRequest({ path: '/audit_logs', method: 'POST', body: [wrapped] });
    return;
  }
  const store = await loadStore();
  store.auditLogs.push(wrapped);
  if (store.auditLogs.length > 5000) store.auditLogs = store.auditLogs.slice(-5000);
  await saveStore(store);
}

export async function enqueueJob(job) {
  const now = new Date().toISOString();
  const item = {
    id: makeJobId(),
    status: 'queued',
    attempts: 0,
    createdAt: now,
    updatedAt: now,
    nextAttemptAt: now,
    ...job
  };
  if (useSupabase) {
    // When a payload is present and contains caseRef, copy it to a top‑level
    // column. This enables simple filtering when claiming jobs by caseRef.
    if (item.payload && item.payload.caseRef) {
      item.caseRef = item.payload.caseRef;
    }
    await supabaseRequest({ path: '/jobs', method: 'POST', body: [item] });
    return item;
  }
  const store = await loadStore();
  store.jobs.push(item);
  if (store.jobs.length > 20000) store.jobs = store.jobs.slice(-20000);
  await saveStore(store);
  return item;
}

export async function claimNextJob(type) {
  if (useSupabase) {
    const nowIso = new Date().toISOString();
    // Retrieve at most one job that is due and matches the type and status.
    // The `or` operator handles null nextAttemptAt values. See Supabase docs for filtering.
    const filter = `/jobs?select=*&type=eq.${encodeURIComponent(type)}&status=in.(queued,retry)&or=(nextAttemptAt.is.null,nextAttemptAt.lte.${encodeURIComponent(
      nowIso
    )})&order=createdAt.asc&limit=1`;
    const jobs = await supabaseRequest({ path: filter, method: 'GET' });
    if (!jobs || jobs.length === 0) return null;
    const job = jobs[0];
    const attempts = Number(job.attempts || 0) + 1;
    const patch = {
      status: 'processing',
      attempts,
      updatedAt: nowIso,
      startedAt: nowIso
    };
    await supabaseRequest({ path: `/jobs?id=eq.${encodeURIComponent(job.id)}`, method: 'PATCH', body: patch });
    return { ...job, ...patch };
  }
  const store = await loadStore();
  const nowMs = Date.now();
  const idx = store.jobs.findIndex((j) => {
    if (j.type !== type) return false;
    if (!(j.status === 'queued' || j.status === 'retry')) return false;
    const dueMs = j.nextAttemptAt ? Date.parse(j.nextAttemptAt) : 0;
    return Number.isNaN(dueMs) || dueMs <= nowMs;
  });
  if (idx === -1) return null;

  const now = new Date().toISOString();
  const job = store.jobs[idx];
  const claimed = { ...job, status: 'processing', attempts: Number(job.attempts || 0) + 1, updatedAt: now, startedAt: now };
  store.jobs[idx] = claimed;
  await saveStore(store);
  return claimed;
}

export async function claimJobByCaseRef(type, caseRef) {
  if (!caseRef) return null;
  if (useSupabase) {
    const nowIso = new Date().toISOString();
    // Fetch a handful of jobs matching the type and status. We cannot filter on
    // JSON fields easily, so we copy caseRef onto the job row when enqueuing.
    const filter = `/jobs?select=*&type=eq.${encodeURIComponent(
      type
    )}&status=in.(queued,retry)&or=(nextAttemptAt.is.null,nextAttemptAt.lte.${encodeURIComponent(
      nowIso
    )})&order=createdAt.asc&limit=25`;
    const jobs = await supabaseRequest({ path: filter, method: 'GET' });
    let job = null;
    if (Array.isArray(jobs)) {
      job = jobs.find((j) => j.caseRef === caseRef || (j.payload && j.payload.caseRef === caseRef));
    }
    if (!job) return null;
    const attempts = Number(job.attempts || 0) + 1;
    const patch = {
      status: 'processing',
      attempts,
      updatedAt: nowIso,
      startedAt: nowIso
    };
    await supabaseRequest({ path: `/jobs?id=eq.${encodeURIComponent(job.id)}`, method: 'PATCH', body: patch });
    return { ...job, ...patch };
  }
  const store = await loadStore();
  const nowMs = Date.now();
  const idx = store.jobs.findIndex((j) => {
    if (j.type !== type) return false;
    if (j.payload?.caseRef !== caseRef) return false;
    if (!(j.status === 'queued' || j.status === 'retry')) return false;
    const dueMs = j.nextAttemptAt ? Date.parse(j.nextAttemptAt) : 0;
    return Number.isNaN(dueMs) || dueMs <= nowMs;
  });
  if (idx === -1) return null;
  const now = new Date().toISOString();
  const job = store.jobs[idx];
  const claimed = { ...job, status: 'processing', attempts: Number(job.attempts || 0) + 1, updatedAt: now, startedAt: now };
  store.jobs[idx] = claimed;
  await saveStore(store);
  return claimed;
}

export async function completeJob(jobId) {
  if (useSupabase) {
    const patch = {
      status: 'completed',
      updatedAt: new Date().toISOString(),
      completedAt: new Date().toISOString(),
      nextAttemptAt: null,
      lastError: null
    };
    await supabaseRequest({ path: `/jobs?id=eq.${encodeURIComponent(jobId)}`, method: 'PATCH', body: patch });
    return;
  }
  const store = await loadStore();
  const idx = store.jobs.findIndex((j) => j.id === jobId);
  if (idx !== -1) {
    store.jobs[idx] = {
      ...store.jobs[idx],
      status: 'completed',
      updatedAt: new Date().toISOString(),
      completedAt: new Date().toISOString(),
      nextAttemptAt: null,
      lastError: null
    };
    await saveStore(store);
  }
}

export async function failJob(jobId, error, maxAttempts = 5) {
  if (useSupabase) {
    const jobs = await supabaseRequest({ path: `/jobs?id=eq.${encodeURIComponent(jobId)}&select=*`, method: 'GET' });
    const j = Array.isArray(jobs) && jobs.length ? jobs[0] : null;
    if (!j) return null;
    const attempts = Number(j.attempts || 0);
    const terminal = attempts >= maxAttempts;
    const waitMs = backoffMs(attempts);
    const nextAttemptAt = terminal ? null : new Date(Date.now() + waitMs).toISOString();
    const patch = {
      status: terminal ? 'failed' : 'retry',
      lastError: String(error || 'unknown error'),
      nextAttemptAt,
      updatedAt: new Date().toISOString()
    };
    await supabaseRequest({ path: `/jobs?id=eq.${encodeURIComponent(jobId)}`, method: 'PATCH', body: patch });
    return { terminal, attempts, nextAttemptAt, waitMs };
  }
  const store = await loadStore();
  const idx = store.jobs.findIndex((j) => j.id === jobId);
  if (idx === -1) return null;
  const j = store.jobs[idx];
  const attempts = Number(j.attempts || 0);
  const terminal = attempts >= maxAttempts;
  const waitMs = backoffMs(attempts);
  const nextAttemptAt = terminal ? null : new Date(Date.now() + waitMs).toISOString();
  store.jobs[idx] = {
    ...j,
    status: terminal ? 'failed' : 'retry',
    lastError: String(error || 'unknown error'),
    nextAttemptAt,
    updatedAt: new Date().toISOString()
  };
  await saveStore(store);
  return { terminal, attempts, nextAttemptAt, waitMs };
}

export async function getMetrics() {
  if (useSupabase) {
    // fetch all orders and jobs; compute counts
    const orders = (await supabaseRequest({ path: '/orders?select=caseRef,status,fulfillmentAttempts,createdAt,updatedAt', method: 'GET' })) || [];
    const processedWebhookEvents = (await supabaseRequest({ path: '/processed_webhook_events?select=eventId', method: 'GET' })) || [];
    const analytics = (await supabaseRequest({ path: '/analytics?select=id', method: 'GET' })) || [];
    const deadLetters = (await supabaseRequest({ path: '/dead_letters?select=id', method: 'GET' })) || [];
    const auditLogs = (await supabaseRequest({ path: '/audit_logs?select=id', method: 'GET' })) || [];
    const jobs = (await supabaseRequest({ path: '/jobs?select=id,status,createdAt,updatedAt,nextAttemptAt', method: 'GET' })) || [];

    const byStatus = orders.reduce((acc, o) => {
      const key = o.status || 'unknown';
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});
    const attempts = orders.reduce((acc, o) => acc + Number(o.fulfillmentAttempts || 0), 0);
    const jobsByStatus = jobs.reduce((acc, j) => {
      const key = j.status || 'unknown';
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});
    const actionableJobs = jobs.filter((j) => j.status === 'queued' || j.status === 'retry');
    const now = Date.now();
    const oldestQueueMs = actionableJobs.length
      ? now - Math.min(...actionableJobs.map((j) => Date.parse(j.createdAt || j.updatedAt || new Date().toISOString())))
      : 0;

    return {
      ordersTotal: orders.length,
      byStatus,
      processedWebhookEvents: processedWebhookEvents.length,
      analyticsEvents: analytics.length,
      deadLetters: deadLetters.length,
      auditLogEvents: auditLogs.length,
      avgFulfillmentAttempts: orders.length ? Number((attempts / orders.length).toFixed(2)) : 0,
      queueDepth: actionableJobs.length,
      queueOldestMs: Math.max(0, oldestQueueMs),
      jobsByStatus
    };
  }
  const store = await loadStore();
  const orders = Object.values(store.orders);
  const byStatus = orders.reduce((acc, o) => {
    acc[o.status || 'unknown'] = (acc[o.status || 'unknown'] || 0) + 1;
    return acc;
  }, {});
  const attempts = orders.reduce((acc, o) => acc + Number(o.fulfillmentAttempts || 0), 0);
  const jobsByStatus = store.jobs.reduce((acc, j) => {
    acc[j.status || 'unknown'] = (acc[j.status || 'unknown'] || 0) + 1;
    return acc;
  }, {});
  const actionableJobs = store.jobs.filter((j) => j.status === 'queued' || j.status === 'retry');
  const oldestQueueMs = actionableJobs.length
    ? Date.now() - Math.min(...actionableJobs.map((j) => Date.parse(j.createdAt || j.updatedAt || new Date().toISOString())))
    : 0;
  return {
    ordersTotal: orders.length,
    byStatus,
    processedWebhookEvents: store.processedWebhookEvents.length,
    analyticsEvents: store.analytics.length,
    deadLetters: store.deadLetters.length,
    auditLogEvents: store.auditLogs.length,
    avgFulfillmentAttempts: orders.length ? Number((attempts / orders.length).toFixed(2)) : 0,
    queueDepth: actionableJobs.length,
    queueOldestMs: Math.max(0, oldestQueueMs),
    jobsByStatus
  };

}