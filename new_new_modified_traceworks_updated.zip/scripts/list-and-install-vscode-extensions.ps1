# list-and-install-vscode-extensions.ps1

# This PowerShell script enumerates all extensions currently installed in
# Visual Studio Code and optionally reinstalls them into the current VS Code
# environment.  It is helpful when migrating your development setup to a
# new machine or when ensuring that a specific set of extensions is
# available for a project.

# -----------------------------------------------------------------------------
# Usage:
#   ./list-and-install-vscode-extensions.ps1
#
# The script performs the following actions:
#   1. Detects if the `code` command-line interface is available on the
#      system.  If not, it will abort with an error.
#   2. Retrieves the list of installed VS Code extensions using
#      `code --list-extensions` and saves it to the file `extensions.txt` in
#      the current working directory.
#   3. Iterates through each extension and calls `code --install-extension`
#      to ensure that it is installed.  If the extension is already
#      installed, the `--force` switch will make sure it is up to date.
#
# Note:  The script uses `--force` when installing extensions to avoid
# prompts and to update the extension if a newer version is available.  You
# can remove `--force` if you prefer not to overwrite existing versions.

param (
    [switch]$SkipInstall = $false
)

# Helper function to write a formatted error and exit
function Write-ErrorAndExit {
    param(
        [string]$Message
    )
    Write-Host "[ERROR] $Message" -ForegroundColor Red
    exit 1
}

# Check if VS Code CLI is available
if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
    Write-ErrorAndExit "VS Code CLI 'code' is not available. Please install Visual Studio Code and ensure the 'code' command is in your PATH."
}

# Retrieve installed extensions
Write-Host "Retrieving installed VS Code extensions..." -ForegroundColor Cyan
$installedExtensions = code --list-extensions

if (-not $installedExtensions) {
    Write-Host "No extensions are currently installed." -ForegroundColor Yellow
    # Still write an empty file for consistency
    Set-Content -Path "extensions.txt" -Value @()
    exit 0
}

# Save the list to a file in the current directory
$extensionsFile = Join-Path -Path (Get-Location) -ChildPath "extensions.txt"
$installedExtensions | Set-Content -Path $extensionsFile
Write-Host "Saved list of extensions to $extensionsFile" -ForegroundColor Green

# Optionally install/update each extension
if (-not $SkipInstall) {
    Write-Host "Ensuring all extensions are installed/up to date..." -ForegroundColor Cyan
    foreach ($extension in $installedExtensions) {
        if ([string]::IsNullOrWhiteSpace($extension)) { continue }
        Write-Host "Installing/updating '$extension'..." -ForegroundColor Gray
        try {
            code --install-extension $extension --force | Out-Null
            Write-Host "✔ $extension installed or updated" -ForegroundColor Green
        } catch {
        # Use $($_) to avoid invalid variable reference when concatenating the error object
        # When concatenating a variable followed by a colon in a string, wrap the variable
        # name in ${} to prevent PowerShell from misinterpreting the colon as part of the
        # variable name. `$($_)` captures the error from the catch block.
        Write-Host "✖ Failed to install/update ${extension}: $($_)" -ForegroundColor Red
        }
    }
    Write-Host "Extension installation complete." -ForegroundColor Cyan
} else {
    Write-Host "SkipInstall flag set; not installing extensions."
}